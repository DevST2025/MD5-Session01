create definer = root@localhost view average_mark_view as
select `s`.`studentId`                     AS `studentId`,
       `s`.`studentName`                   AS `studentName`,
       avg(`quanlydiemthi`.`mark`.`point`) AS `điểm trung bình`
from (`quanlydiemthi`.`student` `s` join `quanlydiemthi`.`mark`
      on ((`s`.`studentId` = `quanlydiemthi`.`mark`.`studentId`)))
group by `s`.`studentId`, `s`.`studentName`;

